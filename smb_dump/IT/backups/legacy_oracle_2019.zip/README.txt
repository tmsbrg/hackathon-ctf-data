Legacy Oracle configs archive — 2019 decommission project.
Inner archive: configs.7z (use 7z x configs.7z to extract).
